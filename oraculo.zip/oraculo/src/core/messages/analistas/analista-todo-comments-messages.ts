// SPDX-License-Identifier: MIT

export const TodoCommentsMessages = {
  todoFound: 'Comentário TODO encontrado',
} as const;
