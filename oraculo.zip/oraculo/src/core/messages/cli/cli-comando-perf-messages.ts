// SPDX-License-Identifier: MIT

export const CliComandoPerfMessages = {
  tituloComparacaoSnapshotsComIcone: (icone: string) =>
    `${icone} Comparação entre snapshots:`,
} as const;
