// SPDX-License-Identifier: MIT
/**
 * Sistema de Pool de Workers para Processamento Paralelo de Arquivos
 *
 * Permite processar múltiplos arquivos em paralelo usando Worker Threads,
 * melhorando a performance em projetos grandes com muitos arquivos.
 */

import * as os from 'node:os';
import * as path from 'node:path';
import { Worker } from 'node:worker_threads';

import { config } from '@core/config/config.js';
import { log } from '@core/messages/index.js';

import type {
  ContextoExecucao,
  FileEntryWithAst,
  MetricaAnalista,
  Ocorrencia,
  Tecnica,
  WorkerPoolOptions,
  WorkerResult,
  WorkerTask,
} from '@';
import { ocorrenciaErroAnalista } from '@';

// Re-exporta os tipos para compatibilidade
export type { WorkerPoolOptions, WorkerResult, WorkerTask };

/**
 * Pool de workers para processamento paralelo de arquivos
 */
export class WorkerPool {
  private maxWorkers: number;
  private batchSize: number;
  private timeoutMs: number;
  private enabled: boolean;
  private activeWorkers = 0;
  private results: WorkerResult[] = [];
  private errors: string[] = [];

  constructor(options: WorkerPoolOptions = {}) {
    // Se o valor foi passado via options usa ele; se config define 0 usamos nº de CPUs
    const configuredMax =
      options.maxWorkers ?? config.WORKER_POOL_MAX_WORKERS ?? 0;
    this.maxWorkers =
      configuredMax > 0 ? configuredMax : Math.max(1, os.cpus().length);
    this.batchSize = options.batchSize ?? 10;
    // Timeout base vindo de opções/config
    let baseTimeout =
      options.timeoutMs ?? config.ANALISE_TIMEOUT_POR_ANALISTA_MS;
    // Permite sobrescrever com variável de ambiente para ambientes de produção
    const envCap = Number(process.env.ORACULO_MAX_ANALYST_TIMEOUT_MS) || 0;
    if (envCap > 0) {
      baseTimeout = Math.min(baseTimeout, envCap);
    } else if (process.env.NODE_ENV === 'production') {
      // Em produção, por padrão, limitamos para não exceder 10s salvo override explícito
      baseTimeout = Math.min(baseTimeout, 10000);
    }
    this.timeoutMs = baseTimeout;
    this.enabled = options.enabled ?? config.WORKER_POOL_ENABLED !== false;

    // Verifica se Worker Threads estão disponíveis
    if (!this.enabled || !Worker) {
      this.enabled = false;
      log.info('Pool de workers desabilitado (Worker Threads não disponível)');
    }
  }

  /**
   * Processa arquivos usando pool de workers
   */
  async processFiles(
    files: FileEntryWithAst[],
    techniques: Tecnica[],
    context: ContextoExecucao,
  ): Promise<{
    occurrences: Ocorrencia[];
    metrics: MetricaAnalista[];
    totalProcessed: number;
    duration: number;
  }> {
    if (!this.enabled || files.length < this.batchSize) {
      // Fallback para processamento sequencial
      return this.processSequentially(files, techniques, context);
    }

    const startTime = performance.now();
    const batches = this.createBatches(files);
    const nonGlobalTechniques = techniques.filter((t) => !t.global);

    log.info(
      `🚀 Iniciando processamento paralelo com ${this.maxWorkers} workers`,
    );
    log.info(
      `📦 ${batches.length} lotes de até ${this.batchSize} arquivos cada`,
    );

    // Processa lotes globais primeiro
    const globalTechniques = techniques.filter((t) => t.global);
    if (globalTechniques.length > 0) {
      await this.processGlobalTechniques(globalTechniques, context);
    }

    // Processa lotes de arquivos em paralelo
    await this.processBatches(batches, nonGlobalTechniques, context);

    const duration = performance.now() - startTime;
    const totalOccurrences = this.results.reduce(
      (sum, r) => sum + r.occurrences.length,
      0,
    );
    const totalMetrics = this.results.flatMap((r) => r.metrics);

    log.info(
      `✅ Processamento paralelo concluído em ${Math.round(duration)}ms`,
    );
    log.info(
      `📊 ${this.results.length} workers, ${files.length} arquivos, ${totalOccurrences} ocorrências`,
    );

    return {
      occurrences: this.results.flatMap((r) => r.occurrences),
      metrics: totalMetrics,
      totalProcessed: files.length,
      duration,
    };
  }

  /**
   * Cria lotes de arquivos para processamento paralelo
   */
  private createBatches(files: FileEntryWithAst[]): FileEntryWithAst[][] {
    const batches: FileEntryWithAst[][] = [];
    for (let i = 0; i < files.length; i += this.batchSize) {
      batches.push(files.slice(i, i + this.batchSize));
    }
    return batches;
  }

  /**
   * Processa técnicas globais (não paralelizáveis)
   */
  private async processGlobalTechniques(
    techniques: Tecnica[],
    context: ContextoExecucao,
  ): Promise<void> {
    for (const technique of techniques) {
      try {
        const startTime = performance.now();
        const result = await this.executeTechniqueWithTimeout(
          technique,
          '', // conteúdo vazio para técnicas globais
          '[global]',
          null, // sem AST
          undefined, // sem fullPath
          context,
        );

        if (result) {
          const occurrences = Array.isArray(result) ? result : [result];
          this.results.push({
            workerId: -1, // ID especial para global
            occurrences,
            metrics: [
              {
                nome: technique.nome || 'global',
                duracaoMs: performance.now() - startTime,
                ocorrencias: occurrences.length,
                global: true,
              },
            ],
            processedFiles: 0,
            errors: [],
            duration: performance.now() - startTime,
          });
        }
      } catch (error) {
        const err = error as Error;
        this.errors.push(
          `Erro em técnica global '${technique.nome}': ${err.message}`,
        );
        this.results.push({
          workerId: -1,
          occurrences: [
            ocorrenciaErroAnalista({
              mensagem: `Falha na técnica global '${technique.nome}': ${err.message}`,
              relPath: '[execução global]',
              origem: technique.nome,
            }),
          ],
          metrics: [],
          processedFiles: 0,
          errors: [err.message],
          duration: 0,
        });
      }
    }
  }

  /**
   * Processa lotes de arquivos em paralelo
   */
  private async processBatches(
    batches: FileEntryWithAst[][],
    techniques: Tecnica[],
    context: ContextoExecucao,
  ): Promise<void> {
    // Conjunto de promises ativas para controle fino (removemos quando conclu eddas)
    const activePromises = new Set<Promise<void>>();

    for (let i = 0; i < batches.length; i++) {
      // Espera até ter vaga para novo worker
      while (this.activeWorkers >= this.maxWorkers) {
        // Aguarda a primeira promise ativa resolver (libera capacidade)
        if (activePromises.size === 0) break;
        await Promise.race(Array.from(activePromises));
      }

      const p = this.processBatch(batches[i], techniques, context, i);
      activePromises.add(p);

      // Quando a promise terminar, remove do conjunto
      p.then(() => activePromises.delete(p)).catch(() =>
        activePromises.delete(p),
      );
    }

    // Aguarda todas as promises ativas terminarem
    await Promise.all(Array.from(activePromises));
  }

  /**
   * Processa um lote de arquivos em um worker
   */
  private async processBatch(
    files: FileEntryWithAst[],
    techniques: Tecnica[],
    context: ContextoExecucao,
    batchId: number,
  ): Promise<void> {
    this.activeWorkers++;

    try {
      const workerPath = path.join(__dirname, 'worker-executor.js');

      // Calcula timeout adaptativo por lote baseado no tamanho médio dos arquivos
      const avgSize =
        files.reduce((s, f) => s + (f.content ? f.content.length : 0), 0) /
        Math.max(1, files.length);
      const sizeMultiplier = 1 + Math.min(4, avgSize / 50000);
      const batchTimeoutMs = Math.max(
        1000,
        Math.min(this.timeoutMs, Math.floor(this.timeoutMs * sizeMultiplier)),
      );

      const worker = new Worker(workerPath, {
        workerData: {
          files,
          techniques,
          context,
          workerId: batchId,
          timeoutMs: batchTimeoutMs,
        } as WorkerTask,
      });

      const workerKillMs = Math.max(30000, this.timeoutMs * 2 || 30000);
      const adjustedKillMs = Math.max(
        1000,
        Math.min(workerKillMs, batchTimeoutMs + 1000),
      );

      const result = await new Promise<WorkerResult>((resolve, reject) => {
        let settled = false;
        // Timer para forçar término caso worker trave por muito tempo
        let killTimer: NodeJS.Timeout | null = setTimeout(() => {
          if (settled) return;
          settled = true;
          try {
            void worker.terminate();
          } catch {
            /* ignore */
          }
          // Log estruturado para kills (ajuda em observabilidade em produção)
          try {
            log.infoSemSanitizar(
              JSON.stringify({
                event: 'worker_killed',
                batchId,
                adjustedKillMs,
                reason: 'timeout',
              }),
            );
          } catch {}
          reject(
            new Error(`Worker ${batchId} killed after ${adjustedKillMs}ms`),
          );
        }, adjustedKillMs);

        worker.on('message', (msg: unknown) => {
          const m = msg as Record<string, unknown>;
          // Heartbeat: rearmar o kill timer
          if (m && m['type'] === 'heartbeat') {
            try {
              if (killTimer) clearTimeout(killTimer);
            } catch {}
            killTimer = setTimeout(() => {
              if (settled) return;
              settled = true;
              try {
                void worker.terminate();
              } catch {}
              try {
                log.infoSemSanitizar(
                  JSON.stringify({
                    event: 'worker_killed',
                    batchId,
                    adjustedKillMs,
                    reason: 'heartbeat_timeout',
                  }),
                );
              } catch {}
              reject(
                new Error(
                  `Worker ${batchId} killed after ${adjustedKillMs}ms (heartbeat timeout)`,
                ),
              );
            }, adjustedKillMs);
            return;
          }

          if (settled) return;
          settled = true;
          try {
            if (killTimer) clearTimeout(killTimer);
          } catch {}
          // Normaliza a mensagem retornada pelo worker para o formato WorkerResult esperado
          try {
            const workerId =
              typeof m['workerId'] === 'number'
                ? (m['workerId'] as number)
                : batchId;
            const occurrences = Array.isArray(m['occurrences'])
              ? (m['occurrences'] as Ocorrencia[])
              : Array.isArray(m['resultados'])
                ? (m['resultados'] as Ocorrencia[])
                : [];
            const metrics = Array.isArray(m['metrics'])
              ? (m['metrics'] as MetricaAnalista[])
              : [];
            const processedFiles =
              typeof m['processedFiles'] === 'number'
                ? (m['processedFiles'] as number)
                : files.length || 0;
            const errors = Array.isArray(m['errors'])
              ? (m['errors'] as string[]).map(String)
              : m['erro']
                ? [String(m['erro'])]
                : [];
            const duration =
              typeof m['duration'] === 'number' ? (m['duration'] as number) : 0;

            const workerResult: WorkerResult = {
              workerId,
              occurrences,
              metrics,
              processedFiles,
              errors: errors as string[],
              duration,
            };
            resolve(workerResult);
          } catch (e) {
            reject(e);
          }
        });

        worker.on('error', (err) => {
          if (settled) return;
          settled = true;
          try {
            if (killTimer) clearTimeout(killTimer);
          } catch {}
          reject(err);
        });

        worker.on('exit', (code) => {
          if (settled) return;
          settled = true;
          try {
            if (killTimer) clearTimeout(killTimer);
          } catch {}
          if (code !== 0) {
            try {
              log.infoSemSanitizar(
                JSON.stringify({ event: 'worker_exit_nonzero', batchId, code }),
              );
            } catch {}
            reject(new Error(`Worker ${batchId} exited with code ${code}`));
          } else {
            resolve({
              workerId: batchId,
              occurrences: [],
              metrics: [],
              processedFiles: files.length,
              errors: [],
              duration: 0,
            });
          }
        });
      });

      this.results.push(result);
    } catch (error) {
      const err = error as Error;
      this.errors.push(`Erro no worker ${batchId}: ${err.message}`);

      // Adiciona resultado de erro
      this.results.push({
        workerId: batchId,
        occurrences: [
          ocorrenciaErroAnalista({
            mensagem: `Falha no worker ${batchId}: ${err.message}`,
            relPath: `[worker-${batchId}]`,
            origem: 'worker-pool',
          }),
        ],
        metrics: [],
        processedFiles: 0,
        errors: [err.message],
        duration: 0,
      });
    } finally {
      this.activeWorkers--;
    }
  }

  /**
   * Processamento sequencial como fallback
   */
  private async processSequentially(
    files: FileEntryWithAst[],
    techniques: Tecnica[],
    context: ContextoExecucao,
  ): Promise<{
    occurrences: Ocorrencia[];
    metrics: MetricaAnalista[];
    totalProcessed: number;
    duration: number;
  }> {
    const startTime = performance.now();
    const occurrences: Ocorrencia[] = [];
    const metrics: MetricaAnalista[] = [];

    log.info('🔄 Usando processamento sequencial (workers desabilitados)');

    // Processa técnicas globais
    const globalTechniques = techniques.filter((t) => t.global);
    for (const technique of globalTechniques) {
      try {
        const result = await this.executeTechniqueWithTimeout(
          technique,
          '',
          '[global]',
          null,
          undefined,
          context,
        );

        if (result) {
          const occs = Array.isArray(result) ? result : [result];
          occurrences.push(...occs);
        }
      } catch (error) {
        const err = error as Error;
        occurrences.push(
          ocorrenciaErroAnalista({
            mensagem: `Falha na técnica global '${technique.nome}': ${err.message}`,
            relPath: '[execução global]',
            origem: technique.nome,
          }),
        );
      }
    }

    // Processa arquivos sequencialmente
    const nonGlobalTechniques = techniques.filter((t) => !t.global);
    for (const file of files) {
      for (const technique of nonGlobalTechniques) {
        if (technique.test && !technique.test(file.relPath)) continue;

        try {
          const startTime = performance.now();
          const result = await this.executeTechniqueWithTimeout(
            technique,
            file.content ?? '',
            file.relPath,
            file.ast && 'node' in file.ast ? file.ast : null,
            file.fullPath,
            context,
          );

          if (result) {
            const occs = Array.isArray(result) ? result : [result];
            occurrences.push(...occs);
          }

          const duration = performance.now() - startTime;
          metrics.push({
            nome: technique.nome || 'desconhecido',
            duracaoMs: duration,
            ocorrencias: Array.isArray(result) ? result.length : result ? 1 : 0,
            global: false,
          });
        } catch (error) {
          const err = error as Error;
          occurrences.push(
            ocorrenciaErroAnalista({
              mensagem: `Falha na técnica '${technique.nome}' para ${file.relPath}: ${err.message}`,
              relPath: file.relPath,
              origem: technique.nome,
            }),
          );
        }
      }
    }

    return {
      occurrences,
      metrics,
      totalProcessed: files.length,
      duration: performance.now() - startTime,
    };
  }

  /**
   * Executa uma técnica com timeout
   */
  private async executeTechniqueWithTimeout(
    technique: Tecnica,
    content: string,
    relPath: string,
    ast: import('@babel/traverse').NodePath<import('@babel/types').Node> | null,
    fullPath: string | undefined,
    context: ContextoExecucao,
  ): Promise<ReturnType<Tecnica['aplicar']>> {
    if (this.timeoutMs > 0) {
      let timer: NodeJS.Timeout | null = null;
      const timeoutPromise = new Promise<never>((_, reject) => {
        timer = setTimeout(() => {
          reject(
            new Error(
              `Timeout: analista '${technique.nome}' excedeu ${this.timeoutMs}ms`,
            ),
          );
        }, this.timeoutMs);
      });

      const execPromise = technique.aplicar(
        content,
        relPath,
        ast,
        fullPath,
        context,
      );
      try {
        return await Promise.race([execPromise, timeoutPromise]);
      } finally {
        if (timer) clearTimeout(timer);
      }
    } else {
      return await technique.aplicar(content, relPath, ast, fullPath, context);
    }
  }

  /**
   * Retorna estatísticas do pool
   */
  getStats(): {
    maxWorkers: number;
    batchSize: number;
    enabled: boolean;
    activeWorkers: number;
    completedWorkers: number;
    totalErrors: number;
    errors: string[];
  } {
    return {
      maxWorkers: this.maxWorkers,
      batchSize: this.batchSize,
      enabled: this.enabled,
      activeWorkers: this.activeWorkers,
      completedWorkers: this.results.length,
      totalErrors: this.errors.length,
      errors: this.errors,
    };
  }
}

/**
 * Função de conveniência para usar o pool de workers
 */

export async function processarComWorkers(
  files: FileEntryWithAst[],
  techniques: Tecnica[],
  context: ContextoExecucao,
  options?: WorkerPoolOptions,
): Promise<{
  occurrences: Ocorrencia[];
  metrics: MetricaAnalista[];
  totalProcessed: number;
  duration: number;
}> {
  const pool = new WorkerPool(options);
  return await pool.processFiles(files, techniques, context);
}
