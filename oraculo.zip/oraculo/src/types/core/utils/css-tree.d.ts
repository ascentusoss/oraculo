// SPDX-License-Identifier: MIT
declare module 'css-tree';
