// SPDX-License-Identifier: MIT
declare module 'postcss-sass';
