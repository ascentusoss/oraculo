// SPDX-License-Identifier: MIT

export interface LinguagensJson {
  total: number;
  extensoes: Record<string, number>;
}
