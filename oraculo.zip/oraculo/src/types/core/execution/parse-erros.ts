// SPDX-License-Identifier: MIT

export interface ParseErrosJson {
  totalOriginais: number;
  totalExibidos: number;
  agregados: number;
}
