// SPDX-License-Identifier: MIT

export interface RegistroIntegridade {
  arquivo: string;
  hash: string;
}
