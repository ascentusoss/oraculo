// SPDX-License-Identifier: MIT
/**
 * Re-export de todos os tipos para compatibilidade
 * Este arquivo permite imports do tipo: import { X } from '@types/types'
 */
export * from './index.js';
