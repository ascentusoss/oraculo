Proveniência e Autoria: Este documento integra o projeto Oráculo (licença MIT).

Arquivo gerado/atualizado automaticamente via `scripts/add-disclaimer-md.js`.
